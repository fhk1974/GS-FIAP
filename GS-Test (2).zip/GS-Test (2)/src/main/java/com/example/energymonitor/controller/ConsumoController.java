package com.example.energymonitor.controller;

import com.example.energymonitor.model.Consumo;
import com.example.energymonitor.service.ConsumoService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/consumo")
public class ConsumoController {

    private final ConsumoService service;

    public ConsumoController(ConsumoService service) {
        this.service = service;
    }

    @GetMapping("/{cidade}")
    public Consumo consultarConsumo(@PathVariable String cidade) {
        return service.obterConsumo(cidade);
    }
}