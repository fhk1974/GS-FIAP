package com.example.energymonitor.model;

public class Consumo {
    private String cidade;
    private double consumoKwh;
    private boolean riscoQueda;

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public double getConsumoKwh() {
        return consumoKwh;
    }

    public void setConsumoKwh(double consumoKwh) {
        this.consumoKwh = consumoKwh;
    }

    public boolean isRiscoQueda() {
        return riscoQueda;
    }

    public void setRiscoQueda(boolean riscoQueda) {
        this.riscoQueda = riscoQueda;
    }
}