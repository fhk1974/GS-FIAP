package com.example.energymonitor.service;

import com.example.energymonitor.model.Consumo;
import org.springframework.stereotype.Service;

@Service
public class ConsumoService {

    public Consumo obterConsumo(String cidade) {
        double consumo = Math.random() * 1000;
        boolean risco = consumo > 800;

        Consumo c = new Consumo();
        c.setCidade(cidade);
        c.setConsumoKwh(consumo);
        c.setRiscoQueda(risco);

        return c;
    }
}