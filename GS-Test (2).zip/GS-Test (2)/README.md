# Energy Monitor - API RESTful

### Integrantes
- Fabio Hideki Kamikihara - RM550610
- Eduardo Osório - RM550161

## Funcionalidades

- Consulta de consumo de energia por cidade
- Simulação de risco de queda de energia
- API RESTful com resposta JSON
- Organização modular com camadas Controller, Service e Model

## Como rodar

```bash
git clone https://github.com/fhk1974/energy-monitor.git
cd energy-monitor
./mvnw spring-boot:run
```

Acesse: `http://localhost:8080/api/consumo/SaoPaulo`